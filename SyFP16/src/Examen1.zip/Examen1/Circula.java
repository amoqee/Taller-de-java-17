/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Examen1;

/**
 *
 * @author Karen
 */
public class Circula extends Megalopolis {
    public String getByPlaca(String digitos ){
        
        if(digitos = 5,6){
            return String lunes;
        }
        
        if(digitos = 7,8){
            return String martes;
        }
        
        if(digitos = 3,4){
            return String miercoles;
        }
        
        if(digitos = 1,2){
            return String jueves;
        }
        
        if(digitos = 9,0){
            return String viernes;
        }  
        
                   
               
        
        
    }
    
    public String getTerminacionPlaca(String num){
        
        if(num = lunes){
            return String 5, 6;
        }
        
        if(num = martes){
            return String 7, 8;
        }
        
        if(num = miercoles){
            return String 3,4;
        }
        
        if(num = jueves){
            return String 1,2;
        }
        
        if(num = viernes){
            return String 9,0;
        }
        
    }
    
    public String getColor(String dia){
        
        if( dia = amarillo){
            return String lunes;
        }
        
        if( dia = rosa){
            return String martes;
        }
        
        if(dia = rojo){
            return String miercoles;
        }
        
        if(dia = verde){
            return String jueves;
        }
        
        if(dia = azul){
            return String viernes;
        }
    }
    
}
