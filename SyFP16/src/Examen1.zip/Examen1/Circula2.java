/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Examen1;

/**
 *
 * @author Karen
 */
public interface Circula2 {
    
    public String getHoynocircula(){
                      
       
      
    }
    
    
    public String getByPlaca(String digitos ){
       
 }
  
    
    public String getTerminacionPlaca(String num){
        
{   
    
    public String getColor(String dia){
        
       
        
}
        
        
         
   
      
   
    

